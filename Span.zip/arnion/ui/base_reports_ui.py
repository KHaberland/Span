class ReportWindow:
    def __init__(self, parameters):
        pass
    def get_report_text(self, parameters):
        pass
    def open(self):
        pass
    def close(self):
        pass
